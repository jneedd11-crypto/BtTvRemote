package com.aburajab.btremote

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity(), HidDeviceManager.Listener {

    private lateinit var hidManager: HidDeviceManager
    private lateinit var tvStatus: TextView
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        val btnConnect = findViewById<Button>(R.id.btnConnect)

        checkPermissions()
        hidManager = HidDeviceManager(this, this)

        btnConnect.setOnClickListener {
            showPairedDevicesDialog()
        }

        setupRemoteButtons()
    }

    private fun setupRemoteButtons() {
        findViewById<Button>(R.id.btnUp).setOnClickListener { hidManager.sendKey(0x52) }
        findViewById<Button>(R.id.btnDown).setOnClickListener { hidManager.sendKey(0x51) }
        findViewById<Button>(R.id.btnLeft).setOnClickListener { hidManager.sendKey(0x50) }
        findViewById<Button>(R.id.btnRight).setOnClickListener { hidManager.sendKey(0x4F) }
        findViewById<Button>(R.id.btnOk).setOnClickListener { hidManager.sendKey(0x28) }

        findViewById<Button>(R.id.btnHome).setOnClickListener { hidManager.sendKey(0x40) }
        findViewById<Button>(R.id.btnBack).setOnClickListener { hidManager.sendKey(0x2A) }
        findViewById<Button>(R.id.btnMenu).setOnClickListener { hidManager.sendKey(0x3B) }
        findViewById<Button>(R.id.btnPower).setOnClickListener { hidManager.sendKey(0x66) }
        findViewById<Button>(R.id.btnRecent).setOnClickListener { hidManager.sendKey(0x3C) }

        findViewById<Button>(R.id.btnVolUp).setOnClickListener { hidManager.sendKey(0x80.toByte()) }
        findViewById<Button>(R.id.btnVolDown).setOnClickListener { hidManager.sendKey(0x81.toByte()) }
        findViewById<Button>(R.id.btnMute).setOnClickListener { hidManager.sendKey(0x7F.toByte()) }

        findViewById<Button>(R.id.btnPlayPause).setOnClickListener { hidManager.sendKey(0xCD.toByte()) }
        findViewById<Button>(R.id.btnStop).setOnClickListener { hidManager.sendKey(0xB7.toByte()) }
        findViewById<Button>(R.id.btnNext).setOnClickListener { hidManager.sendKey(0xB5.toByte()) }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { hidManager.sendKey(0xB6.toByte()) }

        val numbers = mapOf(
            R.id.btn0 to 0x27.toByte(),
            R.id.btn1 to 0x1E.toByte(),
            R.id.btn2 to 0x1F.toByte(),
            R.id.btn3 to 0x20.toByte(),
            R.id.btn4 to 0x21.toByte(),
            R.id.btn5 to 0x22.toByte(),
            R.id.btn6 to 0x23.toByte(),
            R.id.btn7 to 0x24.toByte(),
            R.id.btn8 to 0x25.toByte(),
            R.id.btn9 to 0x26.toByte()
        )
        for ((id, keycode) in numbers) {
            findViewById<Button>(id).setOnClickListener { hidManager.sendKey(keycode) }
        }
    }

    @SuppressLint("MissingPermission")
    private fun showPairedDevicesDialog() {
        val pairedDevices: Set<BluetoothDevice>? = bluetoothAdapter?.bondedDevices
        if (pairedDevices.isNullOrEmpty()) {
            Toast.makeText(this, "لا توجد أجهزة بلوتوث مقترنة مسبقاً!", Toast.LENGTH_LONG).show()
            return
        }

        val deviceList = pairedDevices.toList()
        val deviceNames = deviceList.map { it.name ?: "جهاز غير معروف" }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("اختر جهاز التلفاز أو الـ TV Box")
            .setItems(deviceNames) { _, which ->
                val selectedDevice = deviceList[which]
                hidManager.connectToDevice(selectedDevice)
                Toast.makeText(this, "جاري الاتصال بـ ${selectedDevice.name}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val permissions = arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_SDP,
                Manifest.permission.BLUETOOTH_ADVERTISE
            )
            // Just request standard permissions
        }
    }

    override fun onStatusChanged(status: String, isConnected: Boolean) {
        tvStatus.text = "الحالة: $status"
        tvStatus.textColor = if (isConnected) 0xFF4CAF50.toInt() else 0xFFFF5252.toInt()
    }

    override fun onDestroy() {
        super.onDestroy()
        hidManager.close()
    }
}
