package com.aburajab.btremote

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

class HidDeviceManager(private val context: Context, private val listener: Listener) {

    interface Listener {
        fun onStatusChanged(status: String, isConnected: Boolean)
    }

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var hidDevice: BluetoothHidDevice? = null
    private var connectedDevice: BluetoothDevice? = null
    private val executor = Executors.newSingleThreadExecutor()

    private val sdpSettings = BluetoothHidDeviceAppSdpSettings(
        "Android BT Remote",
        "Bluetooth HID Remote Controller",
        "Custom",
        BluetoothHidDevice.SUBCLASS1_KEYBOARD,
        byteArrayOf(
            0x05.toByte(), 0x01.toByte(),
            0x09.toByte(), 0x06.toByte(),
            0xA1.toByte(), 0x01.toByte(),
            0x85.toByte(), 0x01.toByte(),
            0x05.toByte(), 0x07.toByte(),
            0x19.toByte(), 0xE0.toByte(),
            0x29.toByte(), 0xE7.toByte(),
            0x15.toByte(), 0x00.toByte(),
            0x25.toByte(), 0x01.toByte(),
            0x75.toByte(), 0x01.toByte(),
            0x95.toByte(), 0x08.toByte(),
            0x81.toByte(), 0x02.toByte(),
            0x95.toByte(), 0x01.toByte(),
            0x75.toByte(), 0x08.toByte(),
            0x81.toByte(), 0x03.toByte(),
            0x95.toByte(), 0x05.toByte(),
            0x75.toByte(), 0x01.toByte(),
            0x05.toByte(), 0x08.toByte(),
            0x19.toByte(), 0x01.toByte(),
            0x29.toByte(), 0x05.toByte(),
            0x91.toByte(), 0x02.toByte(),
            0x95.toByte(), 0x01.toByte(),
            0x75.toByte(), 0x03.toByte(),
            0x91.toByte(), 0x03.toByte(),
            0x95.toByte(), 0x06.toByte(),
            0x75.toByte(), 0x08.toByte(),
            0x15.toByte(), 0x00.toByte(),
            0x25.toByte(), 0x65.toByte(),
            0x05.toByte(), 0x07.toByte(),
            0x19.toByte(), 0x00.toByte(),
            0x29.toByte(), 0x65.toByte(),
            0x81.toByte(), 0x00.toByte(),
            0xC0.toByte()
        )
    )

    private val profileListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hidDevice = proxy as BluetoothHidDevice
                try {
                    hidDevice?.registerApp(sdpSettings, null, null, executor, hidCallback)
                } catch (e: SecurityException) {
                    e.printStackTrace()
                }
            }
        }
        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hidDevice = null
                listener.onStatusChanged("خدمة HID مفصولة", false)
            }
        }
    }

    private val hidCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            super.onAppStatusChanged(pluggedDevice, registered)
            if (registered) {
                listener.onStatusChanged("جاهز للاتصال", false)
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            super.onConnectionStateChanged(device, state)
            if (state == BluetoothProfile.STATE_CONNECTED) {
                connectedDevice = device
                Handler(Looper.getMainLooper()).post {
                    try {
                        listener.onStatusChanged("متصل بـ: ${device?.name ?: "التلفاز"}", true)
                    } catch (e: SecurityException) {
                        listener.onStatusChanged("متصل بالتلفاز", true)
                    }
                }
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                connectedDevice = null
                Handler(Looper.getMainLooper()).post {
                    listener.onStatusChanged("تم قطع الاتصال", false)
                }
            }
        }
    }

    init {
        try {
            bluetoothAdapter?.getProfileProxy(context, profileListener, BluetoothProfile.HID_DEVICE)
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    fun sendKey(keyCode: Byte) {
        val device = connectedDevice ?: return
        val pressReport = byteArrayOf(0x01, 0x00, 0x00, keyCode, 0x00, 0x00, 0x00, 0x00)
        try {
            hidDevice?.sendReport(device, 1, pressReport)
            Handler(Looper.getMainLooper()).postDelayed({
                val releaseReport = byteArrayOf(0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00)
                hidDevice?.sendReport(device, 1, releaseReport)
            }, 80)
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    fun connectToDevice(device: BluetoothDevice) {
        try {
            hidDevice?.connect(device)
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    fun close() {
        try {
            bluetoothAdapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hidDevice)
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }
}
